#ifndef _VC_HDRS_H
#define _VC_HDRS_H

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <stdio.h>
#include <dlfcn.h>
#include "svdpi.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef _VC_TYPES_
#define _VC_TYPES_
/* common definitions shared with DirectC.h */

typedef unsigned int U;
typedef unsigned char UB;
typedef unsigned char scalar;
typedef struct { U pkt_c; U pkt_d;} vec32;

#define scalar_0 0
#define scalar_1 1
#define scalar_z 2
#define scalar_x 3

extern long long int ConvUP2LLI(U* pkt_a);
extern void ConvLLI2UP(long long int pkt_a1, U* pkt_a2);
extern long long int GetLLIresult();
extern void StoreLLIresult(const unsigned int* pkt_data);
typedef struct VeriC_Descriptor *vc_handle;

#ifndef SV_3_COMPATIBILITY
#define SV_STRING const char*
#else
#define SV_STRING char*
#endif

#endif /* _VC_TYPES_ */

typedef struct _vcs_dpi_rsrc_msg_struct rsrc_msg_struct;

struct _vcs_dpi_rsrc_msg_struct {
    SV_STRING pkt_scope_name;
    SV_STRING pkt_field_name;
    SV_STRING pkt_type_name;
    SV_STRING pkt_action;
    SV_STRING pkt_accessor;
    SV_STRING pkt_resource;
};

extern int uvm_hdl_check_path(/* INPUT */const char* pkt_path);

extern int uvm_hdl_deposit(/* INPUT */const char* pkt_path, const /* INPUT */svLogicVecVal *pkt_value);

extern int uvm_hdl_force(/* INPUT */const char* pkt_path, const /* INPUT */svLogicVecVal *pkt_value);

extern int uvm_hdl_release_and_read(/* INPUT */const char* pkt_path, /* INOUT */svLogicVecVal *pkt_value);

extern int uvm_hdl_release(/* INPUT */const char* pkt_path);

extern int uvm_hdl_read(/* INPUT */const char* pkt_path, /* OUTPUT */svLogicVecVal *pkt_value);

extern SV_STRING uvm_hdl_read_string(/* INPUT */const char* pkt_path);

extern int uvm_memory_load(
    /* INPUT */const char* pkt_nid,
    /* INPUT */const char* pkt_scope,
    /* INPUT */const char* pkt_fileName,
    /* INPUT */const char* pkt_radix,
    /* INPUT */const char* pkt_startaddr,
    /* INPUT */const char* pkt_endaddr,
    /* INPUT */const char* pkt_types
);

extern SV_STRING uvm_dpi_get_next_arg_c(/* INPUT */int pkt_init);

extern SV_STRING uvm_dpi_get_tool_name_c();

extern SV_STRING uvm_dpi_get_tool_version_c();

extern void* uvm_dpi_regcomp(/* INPUT */const char* pkt_regex);

extern int uvm_dpi_regexec(/* INPUT */void* pkt_preg, /* INPUT */const char* pkt_str);

extern void uvm_dpi_regfree(/* INPUT */void* pkt_preg);

extern int uvm_re_match(/* INPUT */const char* pkt_re, /* INPUT */const char* pkt_str);

extern void uvm_dump_re_cache();

extern SV_STRING uvm_glob_to_re(/* INPUT */const char* pkt_glob);

extern void m__uvm_report_dpi(
    /* INPUT */int pkt_severity,
    /* INPUT */const char* pkt_id,
    /* INPUT */const char* pkt_message,
    /* INPUT */int pkt_verbosity,
    /* INPUT */const char* pkt_filename,
    /* INPUT */int pkt_line
);

extern int parse_rsrc_msg(
    /* INPUT */const char* pkt_message,
    /* OUTPUT */rsrc_msg_struct *pkt__msg_fields
);

extern int parse_phase_msg(
    /* INPUT */const char* pkt_message,
    /* OUTPUT */SV_STRING *pkt_domain,
    /* OUTPUT */SV_STRING *pkt_schedule,
    /* OUTPUT */SV_STRING *pkt_phase
);

extern int find_substr_by_C(
    /* INPUT */const char* pkt_org_str,
    /* INPUT */const char* pkt_search_str
);

extern SV_STRING verdi_dump_resource_value(/* INPUT */const char* pkt_rsrc);

extern int verdi_dump_component_interface(
    /* INPUT */const char* pkt_scope_name,
    /* INPUT */int pkt_streamId
);

extern SV_STRING verdi_upper_scope(
    /* INPUT */const char* pkt_inst_scope_name,
    /* OUTPUT */void* *pkt_upper_scope_pointer
);

extern void verdi_dhier_interface(/* INPUT */const char* pkt_var_name);

extern void retrieve_reg_def_class(
    /* INPUT */const char* pkt_var_name,
    /* INPUT */int pkt__handle,
    /* INPUT */int pkt_is_objid_only
);

extern SV_STRING retrieve_def_class(
    /* INPUT */const char* pkt_var_name,
    /* OUTPUT */int *pkt_objid
);

extern int record_reg_decl_name(
    /* INPUT */int pkt_handle,
    /* INPUT */const char* pkt_parent_var_name,
    /* INPUT */const char* pkt_var_name,
    /* INPUT */const char* pkt_obj_name
);

extern int check_is_sequencer();

extern SV_STRING remove_array_index(
    /* INPUT */const char* pkt_name_w_ary_idx,
    /* OUTPUT */void* *pkt_name_c_ptr
);

extern int pli_dhier_begin_event(/* INPUT */const char* pkt_streamN);

extern void pli_trans_add_class_name_attr(
    /* INPUT */const char* pkt_scope_name,
    /* INPUT */const char* pkt_attribute_value,
    /* INPUT */int pkt_streamId
);

extern void pli_trans_add_vif_attr(
    /* INPUT */const char* pkt_scope_name,
    /* INPUT */int pkt_idx,
    /* INPUT */const char* pkt_attribute_value,
    /* INPUT */int pkt_streamId
);

extern void pli_dhier_set_label(
    /* INPUT */int pkt_handle,
    /* INPUT */const char* pkt_label
);

extern void pli_dhier_add_attribute(
    /* INPUT */int pkt_handle,
    /* INPUT */const char* pkt_attr_name,
    /* INPUT */const char* pkt_attr_value
);

extern void pli_dhier_add_attribute_int(
    /* INPUT */int pkt_handle,
    /* INPUT */const char* pkt_attr_name,
    /* INPUT */int pkt_attr_value
);

extern void pli_dhier_end_event(/* INPUT */int pkt_handle);

extern void fsdbTransDPI_scope_add_logicvec_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */const char* pkt_scope_fullname,
    /* INPUT */const char* pkt_attribute_name,
    const /* INPUT */svLogicVecVal *pkt_attribute,
    /* INPUT */int pkt_numbit,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_scope_add_int_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */const char* pkt_scope_fullname,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */int pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_scope_add_string_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */const char* pkt_scope_fullname,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */const char* pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_scope_add_real_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */const char* pkt_scope_fullname,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */double pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_scope_add_enum_int_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */const char* pkt_scope_fullname,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */unsigned int pkt_enum_id,
    /* INPUT */int pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern int fsdbTransDPI_create_stream_begin(
    /* OUTPUT */int *pkt_state,
    /* INPUT */const char* pkt_stream_fullname,
    /* INPUT */const char* pkt_description,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_define_logicvec_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */int pkt_sid,
    /* INPUT */const char* pkt_attribute_name,
    const /* INPUT */svLogicVecVal *pkt_attribute,
    /* INPUT */int pkt_numbit,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_define_int_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */int pkt_sid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */int pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_define_string_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */int pkt_sid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */const char* pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_define_real_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */int pkt_sid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */double pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_define_enum_int_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */int pkt_sid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */unsigned int pkt_enum_id,
    /* INPUT */int pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_stream_add_logicvec_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */int pkt_sid,
    /* INPUT */const char* pkt_attribute_name,
    const /* INPUT */svLogicVecVal *pkt_attribute,
    /* INPUT */int pkt_numbit,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_stream_add_int_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */int pkt_sid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */int pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_stream_add_string_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */int pkt_sid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */const char* pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_stream_add_real_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */int pkt_sid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */double pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_stream_add_enum_int_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */int pkt_sid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */unsigned int pkt_enum_id,
    /* INPUT */int pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_create_stream_end(
    /* OUTPUT */int *pkt_state,
    /* INPUT */int pkt_sid,
    /* INPUT */const char* pkt_options
);

extern long long fsdbTransDPI_begin(
    /* OUTPUT */int *pkt_state,
    /* INPUT */int pkt_sid,
    /* INPUT */const char* pkt_trans_type,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_set_label(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_label,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_tag(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_tag,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_logicvec_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    const /* INPUT */svLogicVecVal *pkt_attribute,
    /* INPUT */int pkt_numbit,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_bitvec_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    const /* INPUT */svBitVecVal *pkt_attribute,
    /* INPUT */int pkt_numbit,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_int_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */int pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_shortint_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */short int pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_longint_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */long long pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_string_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */const char* pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_real_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */double pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_enum_int_attribute(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */unsigned int pkt_enum_id,
    /* INPUT */int pkt_attribute,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_logicvec_attribute_with_expected_value(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    const /* INPUT */svLogicVecVal *pkt_attribute,
    /* INPUT */int pkt_numbit,
    const /* INPUT */svLogicVecVal *pkt_expected_val,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_bitvec_attribute_with_expected_value(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    const /* INPUT */svBitVecVal *pkt_attribute,
    /* INPUT */int pkt_numbit,
    const /* INPUT */svBitVecVal *pkt_expected_val,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_int_attribute_with_expected_value(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */int pkt_attribute,
    /* INPUT */int pkt_expected_val,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_shortint_attribute_with_expected_value(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */short int pkt_attribute,
    /* INPUT */short int pkt_expected_val,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_longint_attribute_with_expected_value(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */long long pkt_attribute,
    /* INPUT */long long pkt_expected_val,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_string_attribute_with_expected_value(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */const char* pkt_attribute,
    /* INPUT */const char* pkt_expected_val,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_real_attribute_with_expected_value(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */double pkt_attribute,
    /* INPUT */double pkt_expected_val,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_enum_int_attribute_with_expected_value(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_attribute_name,
    /* INPUT */unsigned int pkt_enum_id,
    /* INPUT */int pkt_attribute,
    /* INPUT */int pkt_expected_val,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_end(
    /* OUTPUT */int *pkt_state,
    /* INPUT */long long pkt_tid,
    /* INPUT */const char* pkt_options
);

extern void fsdbTransDPI_add_relation(
    /* OUTPUT */int *pkt_state,
    /* INPUT */const char* pkt_rel_name,
    /* INPUT */long long pkt_master_tid,
    /* INPUT */long long pkt_slave_tid,
    /* INPUT */const char* pkt_options
);

extern unsigned int fsdbTransDPI_get_enum_id(
    /* OUTPUT */int *pkt_state,
    /* INPUT */const char* pkt_enum_var_name
);

extern SV_STRING fsdbTransDPI_get_class_str(
    /* OUTPUT */int *pkt_state,
    /* INPUT */const char* pkt_class_var_name,
    /* INPUT */const char* pkt_options
);

void SdisableFork();

#ifdef __cplusplus
}
#endif

#endif //#ifndef _VC_HDRS_H